"""Explanation generation for PEAK privacy predictions."""

from typing import Any, Dict, List, Optional, Tuple, Union
import ast

import numpy as np
import pandas as pd

from peak.config.logging_config import get_logger
from peak.config.settings import settings

logger = get_logger(__name__)


class ExplanationError(Exception):
    """Custom exception for explanation generation errors."""
    pass


class ExplanationGenerator:
    """Generate explanations for PEAK privacy predictions using four categories."""
    
    def __init__(
        self,
        dominant_threshold: Optional[float] = None,
        opponent_threshold: Optional[float] = None,
        collaborative_threshold: Optional[float] = None
    ):
        """
        Initialize explanation generator.
        
        Args:
            dominant_threshold: Threshold for dominant category
            opponent_threshold: Threshold for opponent category  
            collaborative_threshold: Threshold for collaborative category
        """
        self.dominant_threshold = dominant_threshold or settings.dominant_threshold
        self.opponent_threshold = opponent_threshold or settings.opponent_threshold
        self.collaborative_threshold = collaborative_threshold or settings.collaborative_threshold
        
        logger.info("ExplanationGenerator initialized",
                   dominant_threshold=self.dominant_threshold,
                   opponent_threshold=self.opponent_threshold,
                   collaborative_threshold=self.collaborative_threshold)
    
    def generate_explanations(
        self,
        shap_values_df: pd.DataFrame,
        topic_features_df: pd.DataFrame,
        test_df: pd.DataFrame,
        topic_tag_mapping: Optional[Dict[int, List[str]]] = None
    ) -> Dict[str, Any]:
        """
        Generate explanations for all samples using four categories.
        
        Args:
            shap_values_df: DataFrame with SHAP values for each sample
            topic_features_df: DataFrame with topic feature values
            test_df: Original test dataset with labels
            topic_tag_mapping: Mapping from topic IDs to tag lists
            
        Returns:
            Dictionary with explanation categories and samples
        """
        logger.info("Generating explanations for all samples", num_samples=len(shap_values_df))
        
        try:
            # Prepare data
            shap_df_processed, shap_df_abs, shap_df_normalized = self._prep_df(
                shap_values_df, topic_features_df
            )
            
            # Get public and private indices
            indexes_public = list(test_df[test_df['normalizedpublic'] == 1.0].index)
            indexes_private = list(test_df[test_df['normalizedpublic'] != 1.0].index)
            
            # Categorize explanations
            categories = self._categorize_explanations(
                shap_df_processed, shap_df_abs, shap_df_normalized,
                indexes_public, indexes_private
            )
            
            # Generate explanation dictionary for each category
            explanations = self._create_explanation_dict(
                categories, shap_df_processed, shap_df_normalized,
                test_df, topic_tag_mapping
            )
            
            logger.info("Explanation generation completed",
                       dominant_count=len(categories['dominant']),
                       opponent_count=len(categories['opponent']),
                       collaborative_count=len(categories['collaborative']),
                       weak_count=len(categories['weak']))
            
            return explanations
            
        except Exception as e:
            logger.error("Failed to generate explanations", error=str(e))
            raise ExplanationError(f"Failed to generate explanations: {e}")
    
    def _prep_df(
        self, 
        shap_values_df: pd.DataFrame, 
        topic_features_df: pd.DataFrame
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Prepare DataFrames for explanation generation.
        
        Args:
            shap_values_df: SHAP values DataFrame
            topic_features_df: Topic features DataFrame
            
        Returns:
            Tuple of (processed_shap, absolute_shap, normalized_shap)
        """
        # Copy SHAP values (first 20 columns for topics)
        shap_df = shap_values_df.copy().iloc[:, :20]
        
        # Create topic column mapping
        columns_dict = {i: f"topic_{i}" for i in range(20)}
        
        # Get boolean matrix for active topics
        topic_list = list(topic_features_df.apply(
            lambda x: x > 0, raw=True
        ).apply(
            lambda x: list(topic_features_df.columns[x.values]), axis=1
        ))
        
        boolean_idx_matrix = np.zeros((len(shap_df), 20), dtype=bool)
        pd_idx = pd.Index(list(range(20)))
        
        for idx in range(len(shap_df)):
            boolean_idx_matrix[idx] = pd_idx.isin([
                k for k, v in columns_dict.items() 
                if v in topic_list[idx]
            ])
        
        # Zero out SHAP values for inactive topics
        for i in range(boolean_idx_matrix.shape[0]):
            for j in range(boolean_idx_matrix.shape[1]):
                if not boolean_idx_matrix[i][j]:
                    shap_df.at[i, columns_dict[j]] = 0
        
        # Create absolute and normalized versions
        shap_df_abs = shap_df.abs()
        shap_df_normalized = shap_df_abs.div(shap_df_abs.sum(axis=1), axis=0)
        
        return shap_df, shap_df_abs, shap_df_normalized
    
    def _categorize_explanations(
        self,
        shap_df: pd.DataFrame,
        shap_df_abs: pd.DataFrame, 
        shap_df_normalized: pd.DataFrame,
        indexes_public: List[int],
        indexes_private: List[int]
    ) -> Dict[str, List[int]]:
        """
        Categorize explanations into four types.
        
        Args:
            shap_df: Processed SHAP values
            shap_df_abs: Absolute SHAP values
            shap_df_normalized: Normalized SHAP values
            indexes_public: Indices of public samples
            indexes_private: Indices of private samples
            
        Returns:
            Dictionary with category names and sample indices
        """
        # Category 1: Dominant
        dominant_indices = self._cat_dominant(shap_df_normalized, indexes_public, indexes_private)
        
        # Category 2: Opponent
        opponent_indices = self._cat_opponent(
            shap_df_normalized, shap_df, indexes_public, indexes_private, dominant_indices
        )
        
        # Category 3: Collaborative
        collaborative_indices = self._cat_collaborative(
            shap_df, indexes_public, indexes_private, dominant_indices, opponent_indices
        )
        
        # Category 4: Weak (everything else)
        all_indices = set(shap_df.index)
        used_indices = set(dominant_indices + opponent_indices + collaborative_indices)
        weak_indices = list(all_indices - used_indices)
        
        return {
            'dominant': dominant_indices,
            'opponent': opponent_indices,
            'collaborative': collaborative_indices,
            'weak': weak_indices
        }
    
    def _cat_dominant(
        self, 
        shap_df_normalized: pd.DataFrame,
        indexes_public: List[int],
        indexes_private: List[int]
    ) -> List[int]:
        """
        Identify samples with dominant explanations.
        
        Args:
            shap_df_normalized: Normalized SHAP values
            indexes_public: Public sample indices
            indexes_private: Private sample indices
            
        Returns:
            List of dominant sample indices
        """
        # Separate public and private samples
        df_dominant_private_base = shap_df_normalized.loc[indexes_private]
        df_dominant_public_base = shap_df_normalized.loc[indexes_public]
        
        # Find samples with max value above threshold
        df_dominant_private = df_dominant_private_base[
            df_dominant_private_base.max(axis=1) >= self.dominant_threshold
        ]
        df_dominant_public = df_dominant_public_base[
            df_dominant_public_base.max(axis=1) >= self.dominant_threshold
        ]
        
        # Combine and return indices
        df_dominant = pd.concat([df_dominant_private, df_dominant_public])
        return list(df_dominant.index)
    
    def _cat_opponent(
        self,
        shap_df_normalized: pd.DataFrame,
        shap_df: pd.DataFrame,
        indexes_public: List[int],
        indexes_private: List[int],
        dominant_indices: List[int],
        opponent_ub_2: int = 1,
        paired_ub: float = 0.1
    ) -> List[int]:
        """
        Identify samples with opposing explanations.
        
        Args:
            shap_df_normalized: Normalized SHAP values
            shap_df: Raw SHAP values
            indexes_public: Public sample indices
            indexes_private: Private sample indices
            dominant_indices: Already categorized dominant indices
            opponent_ub_2: Minimum number of opposing features
            paired_ub: Threshold for paired opposing features
            
        Returns:
            List of opponent sample indices
        """
        # Get samples above opponent threshold
        df_private_base = shap_df_normalized.loc[indexes_private]
        df_public_base = shap_df_normalized.loc[indexes_public]
        
        df_private = df_private_base.apply(lambda x: x >= self.opponent_threshold)
        df_public = df_public_base.apply(lambda x: x >= self.opponent_threshold)
        
        df_combined = pd.concat([df_private, df_public])
        
        # Filter samples with at least 2 valid elements
        df_filtered = df_combined.loc[df_combined.sum(axis=1) >= 2]
        df_shap_filtered = shap_df[df_filtered].dropna(how='all')
        
        # Count positive and negative contributions
        df_negatives = df_shap_filtered[df_shap_filtered < 0] < 0
        df_positives = df_shap_filtered[df_shap_filtered > 0] > 0
        
        df_counts = pd.DataFrame({
            'negatives': df_negatives.sum(axis=1),
            'positives': df_positives.sum(axis=1)
        })
        
        # Find samples with both positive and negative contributions
        df_opponent = df_counts[
            (df_counts["negatives"] >= opponent_ub_2) & 
            (df_counts["positives"] >= opponent_ub_2)
        ]
        
        # Remove dominant samples
        idx_intersect = list(set(df_opponent.index) & set(dominant_indices))
        df_opponent = df_opponent.drop(idx_intersect)
        
        # Filter by paired threshold
        opponent_indices = []
        for idx in df_opponent.index:
            if abs(shap_df.iloc[idx].min() + shap_df.iloc[idx].max()) < paired_ub:
                opponent_indices.append(idx)
        
        return opponent_indices
    
    def _cat_collaborative(
        self,
        shap_df: pd.DataFrame,
        indexes_public: List[int],
        indexes_private: List[int], 
        dominant_indices: List[int],
        opponent_indices: List[int]
    ) -> List[int]:
        """
        Identify samples with collaborative explanations.
        
        Args:
            shap_df: Raw SHAP values
            indexes_public: Public sample indices
            indexes_private: Private sample indices
            dominant_indices: Already categorized dominant indices
            opponent_indices: Already categorized opponent indices
            
        Returns:
            List of collaborative sample indices
        """
        # Calculate positive and negative contributions
        df_negatives = shap_df[shap_df < 0].sum(axis=1).abs()
        df_positives = shap_df[shap_df > 0].sum(axis=1)
        
        df_sums = pd.DataFrame({
            'negatives': df_negatives,
            'positives': df_positives
        })
        df_sums['total'] = df_sums.sum(axis=1)
        df_sums['res_neg'] = df_sums['negatives'] / df_sums['total']
        df_sums['res_pos'] = df_sums['positives'] / df_sums['total']
        
        # Separate by public/private
        df_private_base = df_sums.loc[indexes_private]
        df_public_base = df_sums.loc[indexes_public]
        
        # Find collaborative samples
        private_neg = list(df_private_base[
            df_private_base["res_neg"] >= self.collaborative_threshold
        ].index)
        private_pos = list(df_private_base[
            df_private_base["res_pos"] >= self.collaborative_threshold
        ].index)
        
        public_neg = list(df_public_base[
            df_public_base["res_neg"] >= self.collaborative_threshold
        ].index)
        public_pos = list(df_public_base[
            df_public_base["res_pos"] >= self.collaborative_threshold
        ].index)
        
        collaborative_indices = private_neg + private_pos + public_neg + public_pos
        
        # Remove already categorized samples
        used_indices = set(dominant_indices + opponent_indices)
        collaborative_indices = [idx for idx in collaborative_indices if idx not in used_indices]
        
        return collaborative_indices
    
    def _create_explanation_dict(
        self,
        categories: Dict[str, List[int]],
        shap_df: pd.DataFrame,
        shap_df_normalized: pd.DataFrame,
        test_df: pd.DataFrame,
        topic_tag_mapping: Optional[Dict[int, List[str]]] = None
    ) -> Dict[str, Any]:
        """
        Create explanation dictionary with topics and categories.
        
        Args:
            categories: Categorized sample indices
            shap_df: Raw SHAP values
            shap_df_normalized: Normalized SHAP values
            test_df: Test dataset
            topic_tag_mapping: Mapping from topics to tags
            
        Returns:
            Dictionary with explanation categories and metadata
        """
        # Create topic dictionaries for each category
        dominant_dict = shap_df_normalized.loc[categories['dominant']].idxmax(axis=1).to_dict()
        
        # Opponent category: min and max topics
        opponent_dict = {}
        for idx in categories['opponent']:
            min_topic = shap_df.loc[idx].idxmin()
            max_topic = shap_df.loc[idx].idxmax()
            opponent_dict[idx] = (min_topic, max_topic)
        
        # Collaborative category: top 3 topics
        collaborative_dict = {}
        for idx in categories['collaborative']:
            top_topics = shap_df_normalized.loc[idx].nlargest(3).index.tolist()
            collaborative_dict[idx] = top_topics
        
        # Weak category: complex logic for top positive/negative topics
        weak_dict = {}
        for idx in categories['weak']:
            # Get top 3 topics by normalized values
            top_weak = shap_df_normalized.loc[idx].nlargest(3).index.tolist()
            
            # Get top positive and negative topics
            row_values = shap_df.loc[idx]
            top_positive = row_values.nlargest(3).index.tolist()
            top_negative = row_values.nsmallest(3).index.tolist()
            
            # Find intersections
            intersection_pos = list(set(top_weak) & set(top_positive))
            intersection_neg = list(set(top_weak) & set(top_negative))
            
            weak_dict[idx] = [intersection_neg, intersection_pos]
        
        # Merge all category dictionaries
        cat_topic_dict = {}
        
        for key, value in dominant_dict.items():
            cat_topic_dict[key] = ['dominant', value]
            
        for key, value in opponent_dict.items():
            cat_topic_dict[key] = ['opponent', value]
            
        for key, value in collaborative_dict.items():
            cat_topic_dict[key] = ['collaborative', value]
            
        for key, value in weak_dict.items():
            cat_topic_dict[key] = ['weak', value]
        
        # Sort by index
        cat_topic_dict = dict(sorted(cat_topic_dict.items(), key=lambda item: item[0]))
        
        return {
            'category_topic_mapping': cat_topic_dict,
            'categories': categories,
            'topic_tag_mapping': topic_tag_mapping,
            'summary': {
                'total_samples': len(cat_topic_dict),
                'dominant_count': len(categories['dominant']),
                'opponent_count': len(categories['opponent']),
                'collaborative_count': len(categories['collaborative']),
                'weak_count': len(categories['weak'])
            }
        }
    
    def generate_text_explanation(
        self,
        sample_idx: int,
        category: str,
        topics: Union[str, Tuple, List],
        prediction: str,
        truth_label: str,
        topic_tag_mapping: Optional[Dict[int, List[str]]] = None
    ) -> str:
        """
        Generate textual explanation for a specific sample.
        
        Args:
            sample_idx: Sample index
            category: Explanation category
            topics: Topic(s) involved in explanation
            prediction: Model prediction
            truth_label: Ground truth label
            topic_tag_mapping: Mapping from topics to tags
            
        Returns:
            Textual explanation string
        """
        try:
            if category == "dominant":
                topic = topics
                topic_name = f"topic_{topic}" if isinstance(topic, int) else topic
                tags_text = self._get_tags_text(topic, topic_tag_mapping)
                
                return (f"The generated explanation for this image being assigned to the "
                       f"{prediction} class is that it is related to {topic_name} "
                       f"with these specific tags: {tags_text}")
            
            elif category == "opponent":
                topic_negative, topic_positive = topics
                neg_tags = self._get_tags_text(topic_negative, topic_tag_mapping)
                pos_tags = self._get_tags_text(topic_positive, topic_tag_mapping)
                
                return (f"Even though the image is related to {topic_negative} "
                       f"(tags: {neg_tags}) which signals the {truth_label} class, "
                       f"it is also related to {topic_positive} (tags: {pos_tags}) "
                       f"and for that reason, it is classified as {prediction}.")
            
            elif category == "collaborative":
                topic_names = [f"topic_{t}" if isinstance(t, int) else t for t in topics]
                all_tags = []
                for topic in topics:
                    tags = self._get_tags_text(topic, topic_tag_mapping, return_list=True)
                    all_tags.extend(tags)
                
                return (f"The generated explanation for this image being assigned to the "
                       f"{prediction} class is that it is related to the topics "
                       f"{', '.join(topic_names)} with these specific tags: {', '.join(all_tags)}")
            
            elif category == "weak":
                topic_negative, topic_positive = topics
                neg_names = [f"topic_{t}" if isinstance(t, int) else t for t in topic_negative]
                pos_names = [f"topic_{t}" if isinstance(t, int) else t for t in topic_positive]
                
                return (f"This image shows weak signals from multiple topics. "
                       f"Negative contribution from {', '.join(neg_names)} and "
                       f"positive contribution from {', '.join(pos_names)}, "
                       f"resulting in classification as {prediction}.")
            
            else:
                return f"Unknown explanation category: {category}"
                
        except Exception as e:
            logger.error("Failed to generate text explanation", 
                        sample_idx=sample_idx, 
                        category=category,
                        error=str(e))
            return f"Error generating explanation: {e}"
    
    def _get_tags_text(
        self, 
        topic: Union[int, str], 
        topic_tag_mapping: Optional[Dict[int, List[str]]], 
        return_list: bool = False
    ) -> Union[str, List[str]]:
        """
        Get tags text for a topic.
        
        Args:
            topic: Topic identifier
            topic_tag_mapping: Mapping from topics to tags
            return_list: Whether to return list or comma-separated string
            
        Returns:
            Tags as string or list
        """
        if topic_tag_mapping is None:
            return "N/A" if not return_list else ["N/A"]
        
        # Extract topic number if string format
        if isinstance(topic, str) and topic.startswith('topic_'):
            topic_num = int(topic.split('_')[1])
        else:
            topic_num = int(topic)
        
        tags = topic_tag_mapping.get(topic_num, ["unknown"])
        
        if return_list:
            return tags
        else:
            return ", ".join(tags[:5])  # Limit to first 5 tags