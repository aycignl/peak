"""Data validation utilities for PEAK."""

from typing import Any, Dict, List, Optional, Tuple
import pandas as pd
import numpy as np
from pathlib import Path

from peak.config.logging_config import get_logger

logger = get_logger(__name__)


class ValidationError(Exception):
    """Custom exception for data validation errors."""
    pass


class DataValidator:
    """Data validation utilities for PEAK."""
    
    def __init__(self):
        """Initialize data validator."""
        logger.info("DataValidator initialized")
    
    def validate_training_data(
        self,
        df: pd.DataFrame,
        required_columns: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Validate training data for PEAK pipeline.
        
        Args:
            df: DataFrame to validate
            required_columns: List of required column names
            
        Returns:
            Dictionary with validation results
        """
        logger.info("Validating training data", shape=df.shape)
        
        if required_columns is None:
            required_columns = ['image', 'cleaned_tags', 'normalizedpublic']
        
        validation_results = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'statistics': {}
        }
        
        # Check basic DataFrame properties
        self._check_dataframe_basics(df, validation_results)
        
        # Check required columns
        self._check_required_columns(df, required_columns, validation_results)
        
        # Validate specific columns
        if 'cleaned_tags' in df.columns:
            self._validate_tags_column(df, validation_results)
        
        if 'normalizedpublic' in df.columns:
            self._validate_labels_column(df, validation_results)
        
        if 'image' in df.columns:
            self._validate_image_column(df, validation_results)
        
        # Set overall validity
        validation_results['is_valid'] = len(validation_results['errors']) == 0
        
        logger.info("Validation completed",
                   is_valid=validation_results['is_valid'],
                   num_errors=len(validation_results['errors']),
                   num_warnings=len(validation_results['warnings']))
        
        return validation_results
    
    def _check_dataframe_basics(
        self, 
        df: pd.DataFrame, 
        results: Dict[str, Any]
    ) -> None:
        """Check basic DataFrame properties."""
        
        # Check if DataFrame is empty
        if df.empty:
            results['errors'].append("DataFrame is empty")
            return
        
        # Check for duplicate rows
        duplicate_count = df.duplicated().sum()
        if duplicate_count > 0:
            results['warnings'].append(f"Found {duplicate_count} duplicate rows")
        
        # Store basic statistics
        results['statistics']['total_rows'] = len(df)
        results['statistics']['total_columns'] = len(df.columns)
        results['statistics']['memory_usage_mb'] = df.memory_usage(deep=True).sum() / 1024 / 1024
    
    def _check_required_columns(
        self,
        df: pd.DataFrame,
        required_columns: List[str],
        results: Dict[str, Any]
    ) -> None:
        """Check for required columns."""
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            results['errors'].append(f"Missing required columns: {missing_columns}")
        
        # Check for extra columns
        extra_columns = [col for col in df.columns if col not in required_columns]
        if extra_columns:
            results['warnings'].append(f"Extra columns found: {extra_columns}")
        
        results['statistics']['missing_columns'] = missing_columns
        results['statistics']['extra_columns'] = extra_columns
    
    def _validate_tags_column(
        self,
        df: pd.DataFrame,
        results: Dict[str, Any]
    ) -> None:
        """Validate the tags column."""
        
        tags_col = df['cleaned_tags']
        
        # Check for null values
        null_count = tags_col.isnull().sum()
        if null_count > 0:
            results['warnings'].append(f"Found {null_count} null values in tags column")
        
        # Check for empty strings
        empty_count = (tags_col.str.strip() == '').sum()
        if empty_count > 0:
            results['warnings'].append(f"Found {empty_count} empty tag strings")
        
        # Check tag statistics
        non_empty_tags = tags_col[tags_col.str.strip() != '']
        if not non_empty_tags.empty:
            tag_lengths = non_empty_tags.str.split().str.len()
            
            results['statistics']['tags'] = {
                'avg_tags_per_sample': tag_lengths.mean(),
                'min_tags_per_sample': tag_lengths.min(),
                'max_tags_per_sample': tag_lengths.max(),
                'std_tags_per_sample': tag_lengths.std(),
                'null_count': null_count,
                'empty_count': empty_count
            }
            
            # Check for samples with very few tags
            few_tags_count = (tag_lengths < 2).sum()
            if few_tags_count > 0:
                results['warnings'].append(
                    f"Found {few_tags_count} samples with fewer than 2 tags"
                )
    
    def _validate_labels_column(
        self,
        df: pd.DataFrame,
        results: Dict[str, Any]
    ) -> None:
        """Validate the labels column."""
        
        labels_col = df['normalizedpublic']
        
        # Check for null values
        null_count = labels_col.isnull().sum()
        if null_count > 0:
            results['errors'].append(f"Found {null_count} null values in labels column")
        
        # Check label values
        unique_labels = labels_col.dropna().unique()
        expected_labels = {0.0, 1.0}
        
        unexpected_labels = set(unique_labels) - expected_labels
        if unexpected_labels:
            results['errors'].append(
                f"Found unexpected label values: {unexpected_labels}. "
                f"Expected only 0.0 (private) and 1.0 (public)"
            )
        
        # Check label distribution
        if not labels_col.empty:
            label_counts = labels_col.value_counts()
            total_count = len(labels_col)
            
            results['statistics']['labels'] = {
                'distribution': label_counts.to_dict(),
                'public_ratio': label_counts.get(1.0, 0) / total_count,
                'private_ratio': label_counts.get(0.0, 0) / total_count,
                'null_count': null_count
            }
            
            # Check for severe class imbalance
            if len(label_counts) == 2:
                min_class_ratio = label_counts.min() / total_count
                if min_class_ratio < 0.05:  # Less than 5%
                    results['warnings'].append(
                        f"Severe class imbalance detected. "
                        f"Minority class represents only {min_class_ratio:.2%} of data"
                    )
    
    def _validate_image_column(
        self,
        df: pd.DataFrame,
        results: Dict[str, Any]
    ) -> None:
        """Validate the image column."""
        
        image_col = df['image']
        
        # Check for null values
        null_count = image_col.isnull().sum()
        if null_count > 0:
            results['errors'].append(f"Found {null_count} null values in image column")
        
        # Check for duplicate image IDs
        duplicate_count = image_col.duplicated().sum()
        if duplicate_count > 0:
            results['warnings'].append(f"Found {duplicate_count} duplicate image IDs")
        
        # Check image ID format (should be numeric or string)
        if not image_col.empty:
            non_null_images = image_col.dropna()
            
            results['statistics']['images'] = {
                'unique_images': non_null_images.nunique(),
                'total_images': len(non_null_images),
                'duplicate_count': duplicate_count,
                'null_count': null_count
            }
    
    def validate_processed_features(
        self,
        features: np.ndarray,
        labels: np.ndarray,
        expected_n_topics: int = 20
    ) -> Dict[str, Any]:
        """
        Validate processed features and labels.
        
        Args:
            features: Feature matrix
            labels: Label array
            expected_n_topics: Expected number of topics/features
            
        Returns:
            Dictionary with validation results
        """
        logger.info("Validating processed features",
                   features_shape=features.shape,
                   labels_shape=labels.shape)
        
        validation_results = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'statistics': {}
        }
        
        # Check shapes
        if features.shape[0] != labels.shape[0]:
            validation_results['errors'].append(
                f"Feature and label counts don't match: "
                f"features={features.shape[0]}, labels={labels.shape[0]}"
            )
        
        # Check feature dimensions
        if features.shape[1] != expected_n_topics:
            validation_results['warnings'].append(
                f"Unexpected number of features: {features.shape[1]}, "
                f"expected {expected_n_topics}"
            )
        
        # Check for NaN or infinite values
        nan_features = np.isnan(features).sum()
        inf_features = np.isinf(features).sum()
        
        if nan_features > 0:
            validation_results['errors'].append(f"Found {nan_features} NaN values in features")
        
        if inf_features > 0:
            validation_results['errors'].append(f"Found {inf_features} infinite values in features")
        
        # Check feature statistics
        validation_results['statistics']['features'] = {
            'shape': features.shape,
            'mean': np.mean(features),
            'std': np.std(features),
            'min': np.min(features),
            'max': np.max(features),
            'nan_count': nan_features,
            'inf_count': inf_features
        }
        
        # Check labels
        unique_labels = np.unique(labels)
        expected_labels = {0, 1}
        
        if not set(unique_labels).issubset(expected_labels):
            validation_results['errors'].append(
                f"Invalid label values: {unique_labels}. Expected only 0 and 1"
            )
        
        validation_results['statistics']['labels'] = {
            'shape': labels.shape,
            'unique_values': unique_labels.tolist(),
            'distribution': {int(k): int(v) for k, v in zip(*np.unique(labels, return_counts=True))}
        }
        
        # Set overall validity
        validation_results['is_valid'] = len(validation_results['errors']) == 0
        
        return validation_results
    
    def validate_model_inputs(
        self,
        X: np.ndarray,
        y: Optional[np.ndarray] = None
    ) -> Dict[str, Any]:
        """
        Validate inputs for model training/prediction.
        
        Args:
            X: Input features
            y: Target labels (optional)
            
        Returns:
            Dictionary with validation results
        """
        validation_results = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'statistics': {}
        }
        
        # Check X
        if X.size == 0:
            validation_results['errors'].append("Input features array is empty")
        
        if np.any(np.isnan(X)):
            validation_results['errors'].append("Input features contain NaN values")
        
        if np.any(np.isinf(X)):
            validation_results['errors'].append("Input features contain infinite values")
        
        validation_results['statistics']['X'] = {
            'shape': X.shape,
            'dtype': str(X.dtype),
            'range': [float(X.min()), float(X.max())],
            'mean': float(X.mean()),
            'std': float(X.std())
        }
        
        # Check y if provided
        if y is not None:
            if y.size == 0:
                validation_results['errors'].append("Target labels array is empty")
            
            if X.shape[0] != y.shape[0]:
                validation_results['errors'].append(
                    f"Mismatch between features and labels: {X.shape[0]} vs {y.shape[0]}"
                )
            
            if np.any(np.isnan(y)):
                validation_results['errors'].append("Target labels contain NaN values")
            
            validation_results['statistics']['y'] = {
                'shape': y.shape,
                'dtype': str(y.dtype),
                'unique_values': np.unique(y).tolist()
            }
        
        validation_results['is_valid'] = len(validation_results['errors']) == 0
        
        return validation_results
    
    def validate_file_paths(
        self,
        file_paths: Dict[str, str]
    ) -> Dict[str, Any]:
        """
        Validate file paths for data loading.
        
        Args:
            file_paths: Dictionary mapping file types to paths
            
        Returns:
            Dictionary with validation results
        """
        validation_results = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'file_info': {}
        }
        
        for file_type, file_path in file_paths.items():
            path_obj = Path(file_path)
            
            file_info = {
                'exists': path_obj.exists(),
                'is_file': path_obj.is_file() if path_obj.exists() else False,
                'size_mb': None,
                'readable': False
            }
            
            if not path_obj.exists():
                validation_results['errors'].append(f"{file_type} file not found: {file_path}")
            elif not path_obj.is_file():
                validation_results['errors'].append(f"{file_type} path is not a file: {file_path}")
            else:
                try:
                    file_info['size_mb'] = path_obj.stat().st_size / 1024 / 1024
                    file_info['readable'] = True
                except Exception as e:
                    validation_results['errors'].append(
                        f"Cannot access {file_type} file {file_path}: {e}"
                    )
            
            validation_results['file_info'][file_type] = file_info
        
        validation_results['is_valid'] = len(validation_results['errors']) == 0
        
        return validation_results
    
    def create_validation_report(
        self,
        validation_results: Dict[str, Any],
        save_path: Optional[str] = None
    ) -> str:
        """
        Create a human-readable validation report.
        
        Args:
            validation_results: Results from validation methods
            save_path: Optional path to save the report
            
        Returns:
            Report as string
        """
        report_lines = []
        report_lines.append("=== PEAK Data Validation Report ===\n")
        
        # Overall status
        status = "✅ VALID" if validation_results['is_valid'] else "❌ INVALID"
        report_lines.append(f"Status: {status}\n")
        
        # Errors
        if validation_results['errors']:
            report_lines.append("🚨 ERRORS:")
            for error in validation_results['errors']:
                report_lines.append(f"  - {error}")
            report_lines.append("")
        
        # Warnings
        if validation_results['warnings']:
            report_lines.append("⚠️  WARNINGS:")
            for warning in validation_results['warnings']:
                report_lines.append(f"  - {warning}")
            report_lines.append("")
        
        # Statistics
        if validation_results.get('statistics'):
            report_lines.append("📊 STATISTICS:")
            stats = validation_results['statistics']
            
            for key, value in stats.items():
                if isinstance(value, dict):
                    report_lines.append(f"  {key}:")
                    for sub_key, sub_value in value.items():
                        report_lines.append(f"    {sub_key}: {sub_value}")
                else:
                    report_lines.append(f"  {key}: {value}")
            report_lines.append("")
        
        report = "\n".join(report_lines)
        
        # Save if path provided
        if save_path:
            with open(save_path, 'w') as f:
                f.write(report)
            logger.info("Validation report saved", path=save_path)
        
        return report