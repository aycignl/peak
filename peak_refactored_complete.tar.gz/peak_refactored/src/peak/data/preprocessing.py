"""Data preprocessing utilities for PEAK."""

import re
from typing import Any, Dict, List, Optional, Union

import pandas as pd
import numpy as np

from peak.config.logging_config import get_logger

logger = get_logger(__name__)


class DataPreprocessor:
    """Data preprocessing utilities for PEAK."""
    
    def __init__(self):
        """Initialize data preprocessor."""
        logger.info("DataPreprocessor initialized")
    
    def clean_tags(
        self, 
        tags_list: Union[List[str], List[List[str]]], 
        remove_scores: bool = True,
        lowercase: bool = True,
        remove_punctuation: bool = True,
        replace_spaces: bool = True
    ) -> List[str]:
        """
        Clean and preprocess image tags.
        
        Args:
            tags_list: List of tag strings or list of tag lists
            remove_scores: Whether to remove confidence scores from tags
            lowercase: Whether to convert to lowercase
            remove_punctuation: Whether to remove punctuation
            replace_spaces: Whether to replace spaces with underscores
            
        Returns:
            List of cleaned tag strings
        """
        logger.info("Cleaning tags", num_items=len(tags_list))
        
        cleaned_tags = []
        
        for item in tags_list:
            if isinstance(item, list):
                # If item is already a list of tags
                tag_list = item
            else:
                # If item is a string, assume it's space-separated tags
                tag_list = str(item).split()
            
            # Clean each tag
            cleaned_item_tags = []
            for tag in tag_list:
                cleaned_tag = self._clean_single_tag(
                    tag, remove_scores, lowercase, remove_punctuation, replace_spaces
                )
                if cleaned_tag:  # Only add non-empty tags
                    cleaned_item_tags.append(cleaned_tag)
            
            # Join cleaned tags back into a single string
            cleaned_tags.append(' '.join(cleaned_item_tags))
        
        logger.info("Tag cleaning completed", num_cleaned=len(cleaned_tags))
        return cleaned_tags
    
    def _clean_single_tag(
        self, 
        tag: str, 
        remove_scores: bool,
        lowercase: bool,
        remove_punctuation: bool,
        replace_spaces: bool
    ) -> str:
        """
        Clean a single tag.
        
        Args:
            tag: Tag string to clean
            remove_scores: Whether to remove confidence scores
            lowercase: Whether to convert to lowercase
            remove_punctuation: Whether to remove punctuation
            replace_spaces: Whether to replace spaces with underscores
            
        Returns:
            Cleaned tag string
        """
        # Remove confidence scores (e.g., "tag:0.95" -> "tag")
        if remove_scores and ':' in tag:
            tag = tag.split(':')[0]
        
        # Convert to lowercase
        if lowercase:
            tag = tag.lower()
        
        # Remove punctuation (except underscores)
        if remove_punctuation:
            tag = re.sub(r'[^\w\s]', '', tag)
        
        # Replace spaces with underscores
        if replace_spaces:
            tag = tag.replace(' ', '_')
        
        # Remove extra whitespace
        tag = tag.strip()
        
        return tag
    
    def extract_tags_from_clarifai_response(
        self, 
        clarifai_tags: List[Dict[str, Any]],
        max_tags: int = 20,
        min_confidence: float = 0.5
    ) -> List[str]:
        """
        Extract and filter tags from Clarifai API response.
        
        Args:
            clarifai_tags: List of tag dictionaries from Clarifai
            max_tags: Maximum number of tags to return
            min_confidence: Minimum confidence threshold
            
        Returns:
            List of filtered tag names
        """
        logger.info("Extracting tags from Clarifai response", 
                   num_raw_tags=len(clarifai_tags))
        
        filtered_tags = []
        
        for tag_dict in clarifai_tags:
            if isinstance(tag_dict, dict) and 'name' in tag_dict and 'value' in tag_dict:
                if tag_dict['value'] >= min_confidence:
                    filtered_tags.append(tag_dict['name'])
        
        # Sort by confidence (if available) and limit
        if len(clarifai_tags) > 0 and 'value' in clarifai_tags[0]:
            # Sort by confidence score descending
            tag_value_pairs = [
                (tag['name'], tag['value']) 
                for tag in clarifai_tags 
                if tag['value'] >= min_confidence
            ]
            tag_value_pairs.sort(key=lambda x: x[1], reverse=True)
            filtered_tags = [tag for tag, _ in tag_value_pairs[:max_tags]]
        else:
            filtered_tags = filtered_tags[:max_tags]
        
        logger.info("Tag extraction completed", 
                   num_filtered_tags=len(filtered_tags),
                   min_confidence=min_confidence)
        
        return filtered_tags
    
    def prepare_dataframe_for_training(
        self, 
        df: pd.DataFrame,
        tags_column: str = 'extracted_tags',
        label_column: str = 'normalizedpublic',
        image_column: str = 'image'
    ) -> pd.DataFrame:
        """
        Prepare DataFrame for PEAK training pipeline.
        
        Args:
            df: Input DataFrame
            tags_column: Name of column containing tags
            label_column: Name of column containing privacy labels
            image_column: Name of column containing image identifiers
            
        Returns:
            Prepared DataFrame with cleaned_tags column
        """
        logger.info("Preparing DataFrame for training", 
                   input_shape=df.shape,
                   tags_column=tags_column)
        
        prepared_df = df.copy()
        
        # Check required columns
        required_columns = [tags_column, label_column, image_column]
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
        
        # Convert tags to list format if needed
        if tags_column in prepared_df.columns:
            # Handle different tag formats
            prepared_df['cleaned_tags'] = self._process_tags_column(
                prepared_df[tags_column]
            )
        
        # Validate labels
        if label_column in prepared_df.columns:
            prepared_df = self._validate_labels(prepared_df, label_column)
        
        # Add metadata
        prepared_df['num_tags'] = prepared_df['cleaned_tags'].apply(
            lambda x: len(str(x).split()) if pd.notna(x) else 0
        )
        
        logger.info("DataFrame preparation completed",
                   output_shape=prepared_df.shape,
                   avg_tags_per_sample=prepared_df['num_tags'].mean())
        
        return prepared_df
    
    def _process_tags_column(self, tags_series: pd.Series) -> pd.Series:
        """
        Process tags column to create cleaned_tags.
        
        Args:
            tags_series: Series containing tags in various formats
            
        Returns:
            Series with cleaned tag strings
        """
        processed_tags = []
        
        for tags in tags_series:
            if pd.isna(tags):
                processed_tags.append("")
                continue
            
            # Handle different input formats
            if isinstance(tags, str):
                # Already a string, just clean it
                cleaned = self._clean_tag_string(tags)
            elif isinstance(tags, list):
                # List of tags or tag dictionaries
                if len(tags) > 0 and isinstance(tags[0], dict):
                    # List of dictionaries (e.g., from Clarifai)
                    tag_names = self.extract_tags_from_clarifai_response(tags)
                    cleaned = ' '.join(tag_names)
                else:
                    # List of strings
                    cleaned = ' '.join(str(tag) for tag in tags)
                cleaned = self._clean_tag_string(cleaned)
            else:
                # Convert to string and clean
                cleaned = self._clean_tag_string(str(tags))
            
            processed_tags.append(cleaned)
        
        return pd.Series(processed_tags, index=tags_series.index)
    
    def _clean_tag_string(self, tag_string: str) -> str:
        """
        Clean a tag string.
        
        Args:
            tag_string: Raw tag string
            
        Returns:
            Cleaned tag string
        """
        # Remove extra whitespace and normalize
        cleaned = re.sub(r'\s+', ' ', tag_string.strip())
        
        # Remove special characters but keep underscores and spaces
        cleaned = re.sub(r'[^\w\s]', '', cleaned)
        
        # Convert to lowercase
        cleaned = cleaned.lower()
        
        # Replace multiple spaces with single space
        cleaned = re.sub(r'\s+', ' ', cleaned)
        
        return cleaned.strip()
    
    def _validate_labels(self, df: pd.DataFrame, label_column: str) -> pd.DataFrame:
        """
        Validate and clean labels.
        
        Args:
            df: DataFrame to validate
            label_column: Name of label column
            
        Returns:
            DataFrame with validated labels
        """
        # Check for missing labels
        missing_labels = df[label_column].isna().sum()
        if missing_labels > 0:
            logger.warning("Found missing labels", count=missing_labels)
            # Fill missing labels with 0 (private)
            df[label_column] = df[label_column].fillna(0)
        
        # Ensure labels are numeric
        try:
            df[label_column] = pd.to_numeric(df[label_column], errors='coerce')
        except Exception as e:
            logger.error("Failed to convert labels to numeric", error=str(e))
            raise ValueError(f"Invalid label format in column {label_column}")
        
        # Check label distribution
        label_counts = df[label_column].value_counts()
        logger.info("Label distribution", counts=label_counts.to_dict())
        
        return df
    
    def split_data_by_privacy_label(
        self, 
        df: pd.DataFrame,
        label_column: str = 'normalizedpublic'
    ) -> Dict[str, pd.DataFrame]:
        """
        Split data by privacy label.
        
        Args:
            df: Input DataFrame
            label_column: Name of privacy label column
            
        Returns:
            Dictionary with 'public' and 'private' DataFrames
        """
        public_df = df[df[label_column] == 1.0].copy()
        private_df = df[df[label_column] != 1.0].copy()
        
        logger.info("Data split by privacy label",
                   public_count=len(public_df),
                   private_count=len(private_df))
        
        return {
            'public': public_df,
            'private': private_df
        }
    
    def create_text_corpus(
        self, 
        df: pd.DataFrame,
        text_column: str = 'cleaned_tags'
    ) -> List[str]:
        """
        Create text corpus from DataFrame.
        
        Args:
            df: Input DataFrame
            text_column: Name of text column
            
        Returns:
            List of text documents
        """
        if text_column not in df.columns:
            raise ValueError(f"Column {text_column} not found in DataFrame")
        
        # Filter out empty or null values
        corpus = df[text_column].dropna()
        corpus = corpus[corpus.str.strip() != '']
        
        logger.info("Text corpus created", 
                   num_documents=len(corpus),
                   avg_length=corpus.str.len().mean())
        
        return corpus.tolist()
    
    def get_preprocessing_stats(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Get preprocessing statistics.
        
        Args:
            df: Preprocessed DataFrame
            
        Returns:
            Dictionary with preprocessing statistics
        """
        stats = {
            'total_samples': len(df),
            'columns': list(df.columns)
        }
        
        # Tag statistics
        if 'cleaned_tags' in df.columns:
            stats['tag_stats'] = {
                'avg_tags_per_sample': df['cleaned_tags'].str.split().str.len().mean(),
                'max_tags_per_sample': df['cleaned_tags'].str.split().str.len().max(),
                'min_tags_per_sample': df['cleaned_tags'].str.split().str.len().min(),
                'empty_tag_samples': (df['cleaned_tags'].str.strip() == '').sum()
            }
        
        # Label statistics
        if 'normalizedpublic' in df.columns:
            stats['label_stats'] = df['normalizedpublic'].value_counts().to_dict()
        
        return stats