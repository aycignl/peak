"""Privacy classification with explainability for PEAK."""

from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union, Any

import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import shap

from peak.config.logging_config import get_logger
from peak.config.settings import settings

logger = get_logger(__name__)


class ClassificationError(Exception):
    """Custom exception for classification errors."""
    pass


class PrivacyClassifier:
    """Privacy classifier with explainability using Random Forest and SHAP."""
    
    def __init__(
        self,
        random_state: Optional[int] = None,
        max_depth: Optional[int] = None,
        n_estimators: Optional[int] = None
    ):
        """
        Initialize privacy classifier.
        
        Args:
            random_state: Random state for reproducibility (defaults to settings)
            max_depth: Maximum tree depth (defaults to settings)
            n_estimators: Number of trees (defaults to settings)
        """
        self.random_state = random_state or settings.random_state
        self.max_depth = max_depth or settings.max_depth
        self.n_estimators = n_estimators or settings.rf_n_estimators
        
        # Initialize classifier
        self.classifier = RandomForestClassifier(
            random_state=self.random_state,
            max_depth=self.max_depth,
            n_estimators=self.n_estimators
        )
        
        # SHAP explainer
        self.explainer = None
        
        # Model state
        self.is_fitted = False
        self.feature_names = None
        
        logger.info("PrivacyClassifier initialized",
                   random_state=self.random_state,
                   max_depth=self.max_depth,
                   n_estimators=self.n_estimators)
    
    def fit(
        self, 
        X_train: np.ndarray, 
        y_train: np.ndarray,
        feature_names: Optional[List[str]] = None
    ) -> 'PrivacyClassifier':
        """
        Fit the privacy classifier.
        
        Args:
            X_train: Training features
            y_train: Training labels
            feature_names: Optional feature names for interpretability
            
        Returns:
            Self for method chaining
        """
        try:
            logger.info("Fitting privacy classifier", 
                       X_shape=X_train.shape, 
                       y_shape=y_train.shape)
            
            # Fit classifier
            self.classifier.fit(X_train, y_train)
            
            # Set up feature names
            if feature_names:
                self.feature_names = feature_names
            else:
                self.feature_names = [f"topic_{i}" for i in range(X_train.shape[1])]
            
            # Initialize SHAP explainer
            self.explainer = shap.TreeExplainer(self.classifier)
            
            self.is_fitted = True
            
            # Log training performance
            train_pred = self.classifier.predict(X_train)
            train_accuracy = accuracy_score(y_train, train_pred)
            
            logger.info("Privacy classifier fitted successfully",
                       train_accuracy=train_accuracy,
                       n_features=X_train.shape[1])
            
            return self
            
        except Exception as e:
            logger.error("Failed to fit privacy classifier", error=str(e))
            raise ClassificationError(f"Failed to fit classifier: {e}")
    
    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Make predictions on new data.
        
        Args:
            X: Input features
            
        Returns:
            Predicted labels
        """
        if not self.is_fitted:
            raise ClassificationError("Classifier must be fitted before prediction")
        
        try:
            predictions = self.classifier.predict(X)
            logger.info("Predictions made", input_shape=X.shape, num_predictions=len(predictions))
            return predictions
        except Exception as e:
            raise ClassificationError(f"Prediction failed: {e}")
    
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Predict class probabilities.
        
        Args:
            X: Input features
            
        Returns:
            Predicted probabilities
        """
        if not self.is_fitted:
            raise ClassificationError("Classifier must be fitted before prediction")
        
        try:
            probabilities = self.classifier.predict_proba(X)
            logger.info("Probabilities predicted", input_shape=X.shape, output_shape=probabilities.shape)
            return probabilities
        except Exception as e:
            raise ClassificationError(f"Probability prediction failed: {e}")
    
    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray) -> Dict[str, Any]:
        """
        Evaluate classifier performance.
        
        Args:
            X_test: Test features
            y_test: Test labels
            
        Returns:
            Dictionary with evaluation metrics
        """
        if not self.is_fitted:
            raise ClassificationError("Classifier must be fitted before evaluation")
        
        try:
            y_pred = self.predict(X_test)
            
            # Calculate metrics
            accuracy = accuracy_score(y_test, y_pred)
            report = classification_report(y_test, y_pred, output_dict=True)
            cm = confusion_matrix(y_test, y_pred)
            
            evaluation = {
                'accuracy': accuracy,
                'classification_report': report,
                'confusion_matrix': cm.tolist(),
                'test_samples': len(y_test)
            }
            
            logger.info("Model evaluation completed", accuracy=accuracy)
            
            return evaluation
            
        except Exception as e:
            raise ClassificationError(f"Evaluation failed: {e}")
    
    def explain_prediction(self, X: np.ndarray, sample_idx: int = 0) -> Dict[str, Any]:
        """
        Generate SHAP explanation for a single prediction.
        
        Args:
            X: Input features
            sample_idx: Index of sample to explain
            
        Returns:
            Dictionary with explanation data
        """
        if not self.is_fitted or self.explainer is None:
            raise ClassificationError("Classifier and explainer must be initialized")
        
        try:
            # Get SHAP values
            shap_values = self.explainer(X[sample_idx:sample_idx+1])
            
            # Get prediction
            prediction = self.predict(X[sample_idx:sample_idx+1])[0]
            probabilities = self.predict_proba(X[sample_idx:sample_idx+1])[0]
            
            explanation = {
                'sample_idx': sample_idx,
                'prediction': int(prediction),
                'probabilities': probabilities.tolist(),
                'feature_names': self.feature_names,
                'feature_values': X[sample_idx].tolist(),
                'shap_values': shap_values.values.tolist(),
                'base_value': shap_values.base_values.tolist()
            }
            
            logger.info("Explanation generated", sample_idx=sample_idx, prediction=prediction)
            
            return explanation
            
        except Exception as e:
            raise ClassificationError(f"Explanation generation failed: {e}")
    
    def get_feature_importance(self) -> Dict[str, float]:
        """
        Get feature importance from the Random Forest model.
        
        Returns:
            Dictionary mapping feature names to importance scores
        """
        if not self.is_fitted:
            raise ClassificationError("Classifier must be fitted first")
        
        importances = self.classifier.feature_importances_
        
        return {
            name: float(importance) 
            for name, importance in zip(self.feature_names, importances)
        }
    
    def save_model(self, model_path: Union[str, Path]) -> None:
        """
        Save the fitted classifier model.
        
        Args:
            model_path: Path to save the model
        """
        if not self.is_fitted:
            raise ClassificationError("Model must be fitted before saving")
        
        model_path = Path(model_path)
        model_path.parent.mkdir(parents=True, exist_ok=True)
        
        model_data = {
            'classifier': self.classifier,
            'feature_names': self.feature_names,
            'config': {
                'random_state': self.random_state,
                'max_depth': self.max_depth,
                'n_estimators': self.n_estimators
            }
        }
        
        try:
            joblib.dump(model_data, model_path)
            logger.info("Privacy classifier saved", model_path=str(model_path))
        except Exception as e:
            raise ClassificationError(f"Failed to save model: {e}")
    
    def load_model(self, model_path: Union[str, Path]) -> 'PrivacyClassifier':
        """
        Load a fitted classifier model.
        
        Args:
            model_path: Path to the saved model
            
        Returns:
            Self for method chaining
        """
        model_path = Path(model_path)
        
        try:
            model_data = joblib.load(model_path)
            
            self.classifier = model_data['classifier']
            self.feature_names = model_data['feature_names']
            
            # Update config
            config = model_data['config']
            self.random_state = config['random_state']
            self.max_depth = config['max_depth']
            self.n_estimators = config['n_estimators']
            
            # Reinitialize explainer
            self.explainer = shap.TreeExplainer(self.classifier)
            self.is_fitted = True
            
            logger.info("Privacy classifier loaded", model_path=str(model_path))
            return self
            
        except Exception as e:
            raise ClassificationError(f"Failed to load model: {e}")
    
    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about the fitted model.
        
        Returns:
            Dictionary with model information
        """
        if not self.is_fitted:
            return {"fitted": False}
        
        return {
            "fitted": True,
            "n_estimators": self.n_estimators,
            "max_depth": self.max_depth,
            "random_state": self.random_state,
            "n_features": len(self.feature_names) if self.feature_names else 0,
            "feature_names": self.feature_names
        }