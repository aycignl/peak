"""Topic extraction using NMF and TF-IDF for PEAK."""

import math
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import joblib
from sklearn.decomposition import NMF
from sklearn.feature_extraction.text import TfidfVectorizer

from peak.config.logging_config import get_logger
from peak.config.settings import settings

logger = get_logger(__name__)


class TopicExtractionError(Exception):
    """Custom exception for topic extraction errors."""
    pass


class TopicExtractor:
    """Topic extraction using Non-negative Matrix Factorization (NMF) and TF-IDF."""
    
    def __init__(
        self,
        n_topics: Optional[int] = None,
        tfidf_stop_words: Optional[str] = None,
        nmf_init: Optional[str] = None,
        nmf_max_iter: Optional[int] = None,
        random_state: Optional[int] = None
    ):
        """
        Initialize topic extractor.
        
        Args:
            n_topics: Number of topics to extract (defaults to settings)
            tfidf_stop_words: Stop words for TF-IDF (defaults to settings)
            nmf_init: NMF initialization method (defaults to settings)
            nmf_max_iter: Maximum NMF iterations (defaults to settings)
            random_state: Random state for reproducibility (defaults to settings)
        """
        self.n_topics = n_topics or settings.n_topics
        self.tfidf_stop_words = tfidf_stop_words or settings.tfidf_stop_words
        self.nmf_init = nmf_init or settings.nmf_init
        self.nmf_max_iter = nmf_max_iter or settings.nmf_max_iter
        self.random_state = random_state or settings.random_state
        
        # Initialize models
        self.tfidf_vectorizer = TfidfVectorizer(stop_words=self.tfidf_stop_words)
        self.nmf_model = NMF(
            n_components=self.n_topics,
            init=self.nmf_init,
            max_iter=self.nmf_max_iter,
            random_state=self.random_state
        )
        
        # Model state
        self.is_fitted = False
        self.feature_names = None
        self.topic_tag_mapping = None
        
        logger.info("TopicExtractor initialized",
                   n_topics=self.n_topics,
                   tfidf_stop_words=self.tfidf_stop_words,
                   nmf_init=self.nmf_init,
                   random_state=self.random_state)
    
    def fit(self, documents: List[str]) -> 'TopicExtractor':
        """
        Fit the topic extraction model on training documents.
        
        Args:
            documents: List of text documents (cleaned tags)
            
        Returns:
            Self for method chaining
            
        Raises:
            TopicExtractionError: If fitting fails
        """
        try:
            logger.info("Fitting topic extraction model", num_documents=len(documents))
            
            # Fit TF-IDF vectorizer and transform documents
            tfidf_matrix = self.tfidf_vectorizer.fit_transform(documents)
            self.feature_names = self.tfidf_vectorizer.get_feature_names_out()
            
            logger.info("TF-IDF vectorization completed",
                       num_features=len(self.feature_names),
                       matrix_shape=tfidf_matrix.shape)
            
            # Fit NMF model
            nmf_features = self.nmf_model.fit_transform(tfidf_matrix.toarray())
            
            # Create topic-tag mapping
            self.topic_tag_mapping = self._create_topic_tag_mapping()
            
            self.is_fitted = True
            
            logger.info("Topic extraction model fitted successfully",
                       num_topics=self.n_topics,
                       convergence_info=getattr(self.nmf_model, 'n_iter_', 'N/A'))
            
            return self
            
        except Exception as e:
            logger.error("Failed to fit topic extraction model", error=str(e))
            raise TopicExtractionError(f"Failed to fit topic extraction model: {e}")
    
    def transform(self, documents: List[str]) -> np.ndarray:
        """
        Transform documents to topic feature vectors.
        
        Args:
            documents: List of text documents to transform
            
        Returns:
            Topic feature matrix (n_documents, n_topics)
            
        Raises:
            TopicExtractionError: If model not fitted or transformation fails
        """
        if not self.is_fitted:
            raise TopicExtractionError("Model must be fitted before transform")
        
        try:
            logger.info("Transforming documents to topic features", num_documents=len(documents))
            
            # Transform with TF-IDF
            tfidf_matrix = self.tfidf_vectorizer.transform(documents)
            
            # Transform with NMF
            topic_features = self.nmf_model.transform(tfidf_matrix)
            
            logger.info("Document transformation completed",
                       output_shape=topic_features.shape)
            
            return topic_features
            
        except Exception as e:
            logger.error("Failed to transform documents", error=str(e))
            raise TopicExtractionError(f"Failed to transform documents: {e}")
    
    def fit_transform(self, documents: List[str]) -> np.ndarray:
        """
        Fit the model and transform documents in one step.
        
        Args:
            documents: List of text documents
            
        Returns:
            Topic feature matrix
        """
        return self.fit(documents).transform(documents)
    
    def _create_topic_tag_mapping(self, top_n: int = 20) -> Dict[int, List[str]]:
        """
        Create mapping of topics to their most associated tags.
        
        Args:
            top_n: Number of top tags per topic
            
        Returns:
            Dictionary mapping topic IDs to tag lists
        """
        if not self.is_fitted:
            raise TopicExtractionError("Model must be fitted first")
        
        components_df = pd.DataFrame(
            self.nmf_model.components_, 
            columns=self.feature_names
        )
        
        topic_tag_mapping = {}
        for topic_id in range(components_df.shape[0]):
            topic_series = components_df.iloc[topic_id]
            top_tags = list(topic_series.nlargest(top_n).keys())
            topic_tag_mapping[topic_id] = top_tags
        
        logger.info("Topic-tag mapping created",
                   num_topics=len(topic_tag_mapping),
                   tags_per_topic=top_n)
        
        return topic_tag_mapping
    
    def get_topic_tags(self, topic_id: int, top_n: int = 20) -> List[str]:
        """
        Get the top tags for a specific topic.
        
        Args:
            topic_id: Topic identifier
            top_n: Number of top tags to return
            
        Returns:
            List of top tags for the topic
        """
        if not self.is_fitted:
            raise TopicExtractionError("Model must be fitted first")
        
        if topic_id >= self.n_topics:
            raise ValueError(f"Topic ID {topic_id} out of range (0-{self.n_topics-1})")
        
        if self.topic_tag_mapping and topic_id in self.topic_tag_mapping:
            return self.topic_tag_mapping[topic_id][:top_n]
        
        # Fallback: compute on demand
        topic_weights = self.nmf_model.components_[topic_id]
        top_indices = np.argsort(topic_weights)[::-1][:top_n]
        return [self.feature_names[i] for i in top_indices]
    
    def get_all_topic_tags(self, top_n: int = 20) -> pd.DataFrame:
        """
        Get all topics and their associated tags as a DataFrame.
        
        Args:
            top_n: Number of top tags per topic
            
        Returns:
            DataFrame with topics as columns and tags as rows
        """
        if not self.is_fitted:
            raise TopicExtractionError("Model must be fitted first")
        
        topic_data = {}
        for topic_id in range(self.n_topics):
            topic_data[f"topic_{topic_id}"] = self.get_topic_tags(topic_id, top_n)
        
        # Pad lists to same length for DataFrame
        max_length = max(len(tags) for tags in topic_data.values())
        for key, tags in topic_data.items():
            topic_data[key] = tags + [''] * (max_length - len(tags))
        
        return pd.DataFrame(topic_data)
    
    def prepare_labels(self, labels: np.ndarray) -> np.ndarray:
        """
        Prepare labels for classification (convert to binary).
        
        Args:
            labels: Raw label array
            
        Returns:
            Binary label array
        """
        logger.info("Preparing labels", original_shape=labels.shape)
        
        # Convert to binary labels (floor operation as in original)
        binary_labels = np.array([math.floor(x) for x in labels])
        
        logger.info("Labels prepared", unique_values=np.unique(binary_labels))
        
        return binary_labels
    
    def save_model(self, model_path: Union[str, Path]) -> None:
        """
        Save the fitted topic extraction model.
        
        Args:
            model_path: Path to save the model
        """
        if not self.is_fitted:
            raise TopicExtractionError("Model must be fitted before saving")
        
        model_path = Path(model_path)
        model_path.parent.mkdir(parents=True, exist_ok=True)
        
        model_data = {
            'tfidf_vectorizer': self.tfidf_vectorizer,
            'nmf_model': self.nmf_model,
            'feature_names': self.feature_names,
            'topic_tag_mapping': self.topic_tag_mapping,
            'config': {
                'n_topics': self.n_topics,
                'tfidf_stop_words': self.tfidf_stop_words,
                'nmf_init': self.nmf_init,
                'nmf_max_iter': self.nmf_max_iter,
                'random_state': self.random_state
            }
        }
        
        try:
            joblib.dump(model_data, model_path)
            logger.info("Topic extraction model saved", model_path=str(model_path))
        except Exception as e:
            raise TopicExtractionError(f"Failed to save model: {e}")
    
    def load_model(self, model_path: Union[str, Path]) -> 'TopicExtractor':
        """
        Load a fitted topic extraction model.
        
        Args:
            model_path: Path to the saved model
            
        Returns:
            Self for method chaining
        """
        model_path = Path(model_path)
        
        try:
            model_data = joblib.load(model_path)
            
            self.tfidf_vectorizer = model_data['tfidf_vectorizer']
            self.nmf_model = model_data['nmf_model']
            self.feature_names = model_data['feature_names']
            self.topic_tag_mapping = model_data['topic_tag_mapping']
            
            # Update config
            config = model_data['config']
            self.n_topics = config['n_topics']
            self.tfidf_stop_words = config['tfidf_stop_words']
            self.nmf_init = config['nmf_init']
            self.nmf_max_iter = config['nmf_max_iter']
            self.random_state = config['random_state']
            
            self.is_fitted = True
            
            logger.info("Topic extraction model loaded", model_path=str(model_path))
            return self
            
        except Exception as e:
            raise TopicExtractionError(f"Failed to load model: {e}")
    
    def get_model_info(self) -> Dict:
        """
        Get information about the fitted model.
        
        Returns:
            Dictionary with model information
        """
        if not self.is_fitted:
            return {"fitted": False}
        
        return {
            "fitted": True,
            "n_topics": self.n_topics,
            "n_features": len(self.feature_names) if self.feature_names is not None else 0,
            "tfidf_stop_words": self.tfidf_stop_words,
            "nmf_init": self.nmf_init,
            "nmf_max_iter": self.nmf_max_iter,
            "random_state": self.random_state,
            "convergence_iter": getattr(self.nmf_model, 'n_iter_', None)
        }