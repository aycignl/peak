"""Data loading utilities for PEAK."""

import pickle
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import pandas as pd
import numpy as np

from peak.config.logging_config import get_logger
from peak.config.settings import settings

logger = get_logger(__name__)


class DataLoadError(Exception):
    """Custom exception for data loading errors."""
    pass


class DataLoader:
    """Data loader for PEAK datasets and model artifacts."""
    
    def __init__(self, data_dir: Optional[Union[str, Path]] = None):
        """
        Initialize data loader.
        
        Args:
            data_dir: Base directory for data files (defaults to settings)
        """
        self.data_dir = Path(data_dir) if data_dir else settings.data_dir
        self.dataset_dir = self.data_dir / "dataset"
        self.pickle_dir = self.data_dir / "pickle"
        
        logger.info("DataLoader initialized", 
                   data_dir=str(self.data_dir),
                   dataset_dir=str(self.dataset_dir),
                   pickle_dir=str(self.pickle_dir))
    
    def load_csv(self, filename: str, directory: Optional[str] = None) -> pd.DataFrame:
        """
        Load CSV file as pandas DataFrame.
        
        Args:
            filename: Name of CSV file
            directory: Subdirectory (defaults to dataset_dir)
            
        Returns:
            Loaded DataFrame
            
        Raises:
            DataLoadError: If file cannot be loaded
        """
        if directory:
            file_path = self.data_dir / directory / filename
        else:
            file_path = self.dataset_dir / filename
        
        try:
            logger.info("Loading CSV file", file_path=str(file_path))
            df = pd.read_csv(file_path)
            logger.info("Successfully loaded CSV", 
                       file_path=str(file_path),
                       shape=df.shape)
            return df
        except Exception as e:
            raise DataLoadError(f"Failed to load CSV file {file_path}: {e}")
    
    def load_pickle(self, filename: str, directory: Optional[str] = None) -> Any:
        """
        Load pickle file.
        
        Args:
            filename: Name of pickle file
            directory: Subdirectory (defaults to pickle_dir)
            
        Returns:
            Loaded object
            
        Raises:
            DataLoadError: If file cannot be loaded
        """
        if directory:
            file_path = self.data_dir / directory / filename
        else:
            file_path = self.pickle_dir / filename
        
        try:
            logger.info("Loading pickle file", file_path=str(file_path))
            with open(file_path, 'rb') as f:
                obj = pickle.load(f)
            logger.info("Successfully loaded pickle", file_path=str(file_path))
            return obj
        except Exception as e:
            raise DataLoadError(f"Failed to load pickle file {file_path}: {e}")
    
    def save_pickle(self, obj: Any, filename: str, directory: Optional[str] = None) -> None:
        """
        Save object as pickle file.
        
        Args:
            obj: Object to save
            filename: Name of pickle file
            directory: Subdirectory (defaults to pickle_dir)
        """
        if directory:
            file_path = self.data_dir / directory / filename
        else:
            file_path = self.pickle_dir / filename
        
        # Ensure directory exists
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        try:
            logger.info("Saving pickle file", file_path=str(file_path))
            with open(file_path, 'wb') as f:
                pickle.dump(obj, f)
            logger.info("Successfully saved pickle", file_path=str(file_path))
        except Exception as e:
            raise DataLoadError(f"Failed to save pickle file {file_path}: {e}")
    
    def load_training_data(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Load training and test datasets.
        
        Returns:
            Tuple of (train_df, test_df)
        """
        logger.info("Loading training data")
        train_df = self.load_csv("df_train.csv")
        test_df = self.load_csv("df_test.csv")
        
        logger.info("Training data loaded", 
                   train_shape=train_df.shape,
                   test_shape=test_df.shape)
        
        return train_df, test_df
    
    def load_shapley_data(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Load Shapley value datasets.
        
        Returns:
            Tuple of (train_shapley_df, test_shapley_df)
        """
        logger.info("Loading Shapley data")
        train_shapley = self.load_csv("train_df_shapley.csv")
        test_shapley = self.load_csv("test_df_shapley.csv")
        
        logger.info("Shapley data loaded",
                   train_shape=train_shapley.shape,
                   test_shape=test_shapley.shape)
        
        return train_shapley, test_shapley
    
    def load_processed_features(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Load preprocessed features and labels.
        
        Returns:
            Tuple of (train_input, test_input, train_label, test_label)
        """
        logger.info("Loading processed features")
        
        train_input = self.load_pickle("train_input.pickle")
        test_input = self.load_pickle("test_input.pickle") 
        train_label = self.load_pickle("train_label.pickle")
        test_label = self.load_pickle("test_label.pickle")
        
        logger.info("Processed features loaded",
                   train_input_shape=train_input.shape,
                   test_input_shape=test_input.shape,
                   train_label_shape=train_label.shape,
                   test_label_shape=test_label.shape)
        
        return train_input, test_input, train_label, test_label
    
    def save_processed_features(
        self, 
        train_input: np.ndarray,
        test_input: np.ndarray, 
        train_label: np.ndarray,
        test_label: np.ndarray
    ) -> None:
        """
        Save processed features and labels.
        
        Args:
            train_input: Training input features
            test_input: Test input features
            train_label: Training labels
            test_label: Test labels
        """
        logger.info("Saving processed features")
        
        self.save_pickle(train_input, "train_input.pickle")
        self.save_pickle(test_input, "test_input.pickle")
        self.save_pickle(train_label, "train_label.pickle")
        self.save_pickle(test_label, "test_label.pickle")
        
        logger.info("Processed features saved")
    
    def list_available_files(self) -> Dict[str, List[str]]:
        """
        List all available data files.
        
        Returns:
            Dictionary mapping directories to file lists
        """
        available_files = {}
        
        for directory in [self.dataset_dir, self.pickle_dir]:
            if directory.exists():
                files = [f.name for f in directory.iterdir() if f.is_file()]
                available_files[directory.name] = files
            else:
                available_files[directory.name] = []
        
        logger.info("Available files listed", available_files=available_files)
        return available_files
    
    def check_data_integrity(self) -> Dict[str, bool]:
        """
        Check integrity of required data files.
        
        Returns:
            Dictionary mapping file checks to boolean results
        """
        checks = {}
        
        # Check CSV files
        required_csvs = ["df_train.csv", "df_test.csv"]
        for csv_file in required_csvs:
            file_path = self.dataset_dir / csv_file
            checks[f"csv_{csv_file}"] = file_path.exists()
        
        # Check pickle files
        required_pickles = [
            "train_input.pickle", "test_input.pickle", 
            "train_label.pickle", "test_label.pickle"
        ]
        for pickle_file in required_pickles:
            file_path = self.pickle_dir / pickle_file
            checks[f"pickle_{pickle_file}"] = file_path.exists()
        
        logger.info("Data integrity check completed", checks=checks)
        return checks