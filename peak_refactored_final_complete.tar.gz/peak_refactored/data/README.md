# Data Directory

This directory contains the datasets used by the PEAK system for restaurant review analysis.

## Files Description

### Training Data
- `df_train.csv` - Main training dataset with restaurant reviews
- `train_df_shapley.csv` - Training data with SHAP (Shapley) values for feature importance
- `train_input.pickle` - Preprocessed training input features (pickled format)
- `train_label.pickle` - Training labels (pickled format)

### Test Data
- `df_test.csv` - Test dataset for model evaluation
- `test_df_shapley.csv` - Test data with SHAP values
- `test_input.pickle` - Preprocessed test input features (pickled format)
- `test_label.pickle` - Test labels (pickled format)

## Data Format

The CSV files contain restaurant review data with the following typical columns:
- Review text
- Ratings/scores
- Restaurant information
- Feature engineered columns

The pickle files contain preprocessed data ready for machine learning models:
- Input features (vectorized text, numerical features)
- Labels (classification targets)

## Usage

```python
from peak.data.loaders import DataLoader

# Load data using the PEAK data loader
loader = DataLoader()
train_data = loader.load_csv("data/df_train.csv")
test_data = loader.load_csv("data/df_test.csv")

# Load preprocessed pickle files
train_features = loader.load_pickle("data/train_input.pickle")
train_labels = loader.load_pickle("data/train_label.pickle")
```

## Data Privacy

Ensure this data is used in compliance with privacy regulations and the original data source terms of use.