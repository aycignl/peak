# Models Directory

This directory contains trained model artifacts and preprocessed data files used by the PEAK system.

## Model Artifacts

### Preprocessed Data Files
- `train_input.pickle` - Preprocessed training features (vectorized text, numerical features)
- `train_label.pickle` - Training labels for classification
- `test_input.pickle` - Preprocessed test features
- `test_label.pickle` - Test labels for evaluation

## Model Training

The PEAK system uses several types of models:

1. **Topic Extraction Models**
   - Non-negative Matrix Factorization (NMF) for topic modeling
   - TF-IDF vectorization for text preprocessing

2. **Classification Models**
   - Random Forest classifiers for review classification
   - Feature importance analysis using SHAP values

3. **Explanation Generation**
   - Rule-based explanation generation
   - Multiple explanation categories (Dominant, Opposing, Collaborative, Weak)

## Loading Models

```python
from peak.models.topic_extraction import TopicExtractor
from peak.models.classification import ReviewClassifier

# Initialize models
topic_extractor = TopicExtractor()
classifier = ReviewClassifier()

# Load preprocessed data
import pickle
with open("models/train_input.pickle", "rb") as f:
    train_features = pickle.load(f)
with open("models/train_label.pickle", "rb") as f:
    train_labels = pickle.load(f)
```

## Model Persistence

When training new models, they will be automatically saved to this directory with timestamps and version information.

## Model Versioning

- Models are versioned using timestamps
- Configuration files are saved alongside models
- Metrics and performance data are logged